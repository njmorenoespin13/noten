import pytest
from engine import normalize, RegexEngine


@pytest.fixture
def engine():
    return RegexEngine()


def test_normalize_accents_and_case():
    assert normalize("¿Cuánto DEBO?") == "¿cuanto debo?"


def test_structured_pattern_positive_and_negative(engine):
    pattern = (
        r"^\s*(?:(?:quiero|necesito)\s+"
        r"(?:saber|conocer|consultar)\s+)?"
        r"(?:cuanto\s+(?:dinero\s+)?debo|"
        r"cual\s+es\s+mi\s+saldo)\s*[.!?]*$"
    )
    positives = [
        "Quiero saber cuánto dinero debo",
        "Necesito conocer cuánto debo",
        "Cuál es mi saldo"
    ]
    negatives = [
        "Quiero saber el clima",
        "Necesito consultar el horario",
        "Cuál es mi dirección"
    ]
    result = engine.validate(pattern, positives, negatives)
    assert result["valid"] is True
    assert result["recall"] == 100
    assert result["specificity"] == 100


def test_invalid_regex(engine):
    result = engine.validate("(", ["hola"], ["adios"])
    assert result["valid"] is False
    assert result["error"]


def test_false_positive_is_detected(engine):
    result = engine.validate(
        r"\bdeuda\b",
        ["Tengo una deuda"],
        ["No quiero hablar de deuda"]
    )
    assert result["valid"] is False
    assert result["specificity"] == 0


def test_empty_positive_or_negative_dataset(engine):
    result = engine.validate(r"hola", ["hola"], [])
    assert result["valid"] is False
