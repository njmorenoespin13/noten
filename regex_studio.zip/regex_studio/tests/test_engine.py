import pytest
from engine import normalize, RegexEngine


@pytest.fixture
def engine():
    return RegexEngine()


def test_normalize_accents_and_case():
    assert normalize("¿Cuánto DEBO?") == "¿cuanto debo?"


def test_structured_pattern_positive_and_negative(engine):
    pattern = (
        r"^[ ]*(?:(?:quiero|necesito)[ ]+"
        r"(?:saber|conocer|consultar)[ ]+)?"
        r"(?:cu[aá]nto[ ]+(?:dinero[ ]+)?debo|"
        r"cu[aá]l[ ]+es[ ]+mi[ ]+saldo)[ ]*[.!?]*$"
    )
    positives = [
        "Quiero saber cuánto dinero debo",
        "Necesito conocer cuánto debo",
        "Cuál es mi saldo"
    ]
    negatives = [
        "Quiero saber el clima",
        "Necesito consultar el horario",
        "Cuál es mi dirección"
    ]
    result = engine.validate(pattern, positives, negatives)
    assert result["valid"] is True
    assert result["recall"] == 100
    assert result["specificity"] == 100


def test_invalid_regex(engine):
    result = engine.validate("(", ["hola"], ["adios"])
    assert result["valid"] is False
    assert result["error"]


def test_false_positive_is_detected(engine):
    result = engine.validate(
        r"deuda",
        ["Tengo una deuda"],
        ["No quiero hablar de deuda"]
    )
    assert result["valid"] is False
    assert result["specificity"] == 0


def test_empty_positive_or_negative_dataset(engine):
    result = engine.validate(r"hola", ["hola"], [])
    assert result["valid"] is False


def test_bounded_gap_regex_matches_flexible_language(engine):
    pattern = r"(?:perm|solicit|requier)[a-záéíóúüñ]*.{0,40}(?:lin|enlac)[a-záéíóúüñ]*.{0,25}(?:intern|web)[a-záéíóúüñ]*"
    positives = [
        "Necesito permiso para acceder al enlace de internet",
        "Solicito que me compartan el link para ingresar a la web",
        "Requiero un permiso y el enlace interno de consulta"
    ]
    negatives = [
        "Necesito permiso para salir temprano",
        "Compárteme el enlace del documento impreso",
        "Quiero consultar el estado de mi cuenta"
    ]
    result = engine.validate(pattern, positives, negatives)
    assert result["recall"] == 100
    assert result["specificity"] == 100


def test_json_parser_accepts_json_inside_code_fence():
    from engine import LLMClient
    parsed = LLMClient._parse_json('```json\n{"regex":"hola"}\n```')
    assert parsed == {"regex": "hola"}


def test_json_parser_extracts_object_from_surrounding_text():
    from engine import LLMClient
    parsed = LLMClient._parse_json('Respuesta:\n{"regex":"hola"}\nfin')
    assert parsed == {"regex": "hola"}


def test_strict_mode_keeps_key_components_and_allows_punctuation_accents():
    from engine import build_strict_pattern
    pattern, keywords = build_strict_pattern("Necesito permiso para la línea de internet")
    engine = RegexEngine()
    result = engine.validate(
        pattern,
        [
            "Necesito permiso para la línea de internet",
            "permiso, para la linea; de internet",
            "PERMISO ... PARA LA LÍNEA, DE INTERNET",
        ],
        [
            "Necesito permiso para la línea",
            "Necesito para la línea de internet",
            "internet línea permiso",
        ],
    )
    assert keywords == ["permiso", "linea", "internet"]
    assert result["recall"] == 100
    assert result["specificity"] == 100
    assert result["valid"] is True


def test_user_example_strict_regex_matches_postgres_raw_text():
    from engine import build_strict_pattern
    engine = RegexEngine()
    first = "Para calificar el servicio brindado en esta comunicación en unos te llegara un link a tu whatsapp, vale?"
    pattern1, keys1 = build_strict_pattern(first)
    assert keys1 == ["calif", "serv", "comunic", "link"]
    assert engine.validate(pattern1, [first, first.replace("comunicación", "comunicacion")], ["No quiero calificar el servicio"])["recall"] == 100

    second = "Comprendo, por ultimo te contactaré con un asesor especializado para que mire opciones de pago para ti, por favor permanece un momento en línea."
    pattern2, keys2 = build_strict_pattern(second)
    assert keys2 == ["ultimo", "contact", "espec", "opci", "permanec", "linea"]
    result = engine.validate(pattern2, [second, second.replace("contactaré", "contactare").replace("línea", "linea")], ["No quiero contactar a nadie"])
    assert result["recall"] == 100
    assert result["specificity"] == 100


def test_strict_regex_uses_postgresql_friendly_subset():
    from engine import build_strict_pattern
    pattern, _ = build_strict_pattern("Necesito revisar la línea de internet")
    assert "(?" not in pattern
    assert "\\w" not in pattern
    assert "(?<=" not in pattern


def test_python_only_regex_features_are_rejected_for_postgres():
    engine = RegexEngine()
    result = engine.validate(r"(?P<word>hola)\b", ["hola"], ["adios"])
    assert result["valid"] is False
    assert "PostgreSQL ARE" in result["error"]


def test_database_keeps_best_regex_even_when_not_approved(tmp_path, monkeypatch):
    import database as db
    monkeypatch.setattr(db, "DB_PATH", tmp_path / "regex_test.db")
    db.initialize()
    db.create_job("job-1", "frase objetivo", "strict")
    db.finish_job("job-1", "calif.*?serv.*?link", 72.5, "completed_with_best")
    saved = db.get_job("job-1")
    assert saved["final_regex"] == "calif.*?serv.*?link"
    assert saved["status"] == "completed_with_best"


def test_flexible_validation_uses_original_text_and_streams_each_test():
    import asyncio
    engine = RegexEngine()
    events = []

    async def callback(event):
        events.append(event)

    pattern = r"(?:calif|eval).*?(?:serv|atenci[oó]n).*?(?:comunic|llamad).*?(?:link|enlace)"
    result = asyncio.run(engine.validate_live(
        pattern,
        ["Para calificar el servicio brindado en esta comunicación te llegará un link"],
        ["No quiero calificar ningún servicio ni recibir enlaces"],
        callback, 1, "prueba"
    ))
    assert result["positive_passed"] == 1
    assert events[0]["event"] == "test_batch_start"
    assert len([event for event in events if event["event"] == "test"]) == 2
    assert events[-1]["event"] == "test_batch_done"


def test_postgres_compatibility_allows_word_class_and_rejects_lookbehind():
    from engine import postgres_compatibility_error
    assert postgres_compatibility_error(r"(?<!abc)def")
    assert postgres_compatibility_error(r"(?:abc|def)\w+") is None


def test_semantic_run_adapts_next_regex_from_failed_positive_examples(monkeypatch):
    import asyncio
    from config import settings

    engine = RegexEngine()
    monkeypatch.setattr(settings, "max_cycles", 1)
    monkeypatch.setattr(settings, "candidates_per_cycle", 2)
    monkeypatch.setattr(settings, "min_recall", 50)
    monkeypatch.setattr(settings, "min_specificity", 50)
    calls = []

    async def fake_variations(phrase, pattern=""):
        return [
            "Quiero evaluar la atención recibida durante esta llamada y recibir el enlace",
            "¿Me comparten el link para calificar el servicio de esta comunicación?",
        ]

    async def fake_candidate(phrase, feedback, positive_examples, negative_examples):
        calls.append({"feedback": list(feedback), "positives": list(positive_examples)})
        if len(calls) == 1:
            pattern = r"calif.*?serv.*?comunic.*?link"
        else:
            pattern = r"(?:calif|eval).*?(?:serv|atenci[oó]n).*?(?:comunic|llamad).*?(?:link|enlace)"
        return {
            "regex": pattern,
            "explanation": "regex de prueba",
            "structure": {},
            "positive_examples": [],
            "negative_examples": [],
        }

    engine.generate_variations = fake_variations
    engine.generate_candidate = fake_candidate
    events = []

    async def callback(event):
        events.append(event)

    result = asyncio.run(engine.run(
        "job", "Calificar el servicio de esta comunicación y enviar link", callback
    ))
    assert len(calls) == 2
    assert calls[1]["feedback"]
    assert calls[1]["positives"]
    assert any(event["event"] == "test" for event in events)
    assert result["regex"] == r"(?:calif|eval).*?(?:serv|atenci[oó]n).*?(?:comunic|llamad).*?(?:link|enlace)"
