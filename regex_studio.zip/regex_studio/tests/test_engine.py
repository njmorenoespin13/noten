import pytest
from engine import normalize, RegexEngine


@pytest.fixture
def engine():
    return RegexEngine()


def test_normalize_accents_and_case():
    assert normalize("¿Cuánto DEBO?") == "¿cuanto debo?"


def test_structured_pattern_positive_and_negative(engine):
    pattern = (
        r"^\s*(?:(?:quiero|necesito)\s+"
        r"(?:saber|conocer|consultar)\s+)?"
        r"(?:cuanto\s+(?:dinero\s+)?debo|"
        r"cual\s+es\s+mi\s+saldo)\s*[.!?]*$"
    )
    positives = [
        "Quiero saber cuánto dinero debo",
        "Necesito conocer cuánto debo",
        "Cuál es mi saldo"
    ]
    negatives = [
        "Quiero saber el clima",
        "Necesito consultar el horario",
        "Cuál es mi dirección"
    ]
    result = engine.validate(pattern, positives, negatives)
    assert result["valid"] is True
    assert result["recall"] == 100
    assert result["specificity"] == 100


def test_invalid_regex(engine):
    result = engine.validate("(", ["hola"], ["adios"])
    assert result["valid"] is False
    assert result["error"]


def test_false_positive_is_detected(engine):
    result = engine.validate(
        r"\bdeuda\b",
        ["Tengo una deuda"],
        ["No quiero hablar de deuda"]
    )
    assert result["valid"] is False
    assert result["specificity"] == 0


def test_empty_positive_or_negative_dataset(engine):
    result = engine.validate(r"hola", ["hola"], [])
    assert result["valid"] is False


def test_bounded_gap_regex_matches_flexible_language(engine):
    pattern = r"(?:perm|solicit|requier)\w*.{0,40}(?:lin|enlac)\w*.{0,25}(?:intern|web)\w*"
    positives = [
        "Necesito permiso para acceder al enlace de internet",
        "Solicito que me compartan el link para ingresar a la web",
        "Requiero un permiso y el enlace interno de consulta"
    ]
    negatives = [
        "Necesito permiso para salir temprano",
        "Compárteme el enlace del documento impreso",
        "Quiero consultar el estado de mi cuenta"
    ]
    result = engine.validate(pattern, positives, negatives)
    assert result["recall"] == 100
    assert result["specificity"] == 100


def test_json_parser_accepts_json_inside_code_fence():
    from engine import LLMClient
    parsed = LLMClient._parse_json('```json\n{"regex":"hola"}\n```')
    assert parsed == {"regex": "hola"}


def test_json_parser_extracts_object_from_surrounding_text():
    from engine import LLMClient
    parsed = LLMClient._parse_json('Respuesta:\n{"regex":"hola"}\nfin')
    assert parsed == {"regex": "hola"}
