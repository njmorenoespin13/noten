# Regex Intelligence Studio

Aplicación local para proponer regex lingüísticos flexibles, probarlos en vivo,
comparar versiones y conservar el historial. Incluye FastAPI, WebSockets,
SQLite y conexión con Ollama o un endpoint OpenAI-compatible.

## Cambios de esta versión

- El prompt ahora pide patrones estructurados por fragmentos semánticos, con
  alternativas y distancias acotadas (`.{0,40}`, `\\w*`, grupos `(?:...)`).
  Evita frases literales completas y coincidencias basadas en una sola palabra.
- Para Ollama nativo se envía un JSON Schema en `format`, en lugar de confiar
  únicamente en que el modelo recuerde producir JSON válido.
- Temperatura 0 por defecto y modelo inicial `qwen3.5:4b`.
- Las pruebas se emiten individualmente por WebSocket y aparecen en la interfaz
  conforme se ejecutan, con PASS/FAIL, tipo, frase y contador.
- Se reproduce el historial de eventos al conectar el WebSocket; así no se
  pierden las interacciones si la tarea empieza antes de abrir el socket.
- Se guardan candidatos, métricas, pruebas y eventos en SQLite.

## Requisitos e instalación

Python 3.10+, Ollama instalado y el modelo descargado.

### Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
ollama pull qwen3.5:4b
```

### Windows PowerShell

```powershell
py -m venv venv
venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
ollama pull qwen3.5:4b
```

## Configuración recomendada para Ollama

El endpoint nativo `/api/chat` permite usar JSON Schema estructurado:

```env
LLM_API_URL=http://127.0.0.1:11434/api/chat
LLM_MODEL=qwen3.5:4b
LLM_API_KEY=
LLM_TEMPERATURE=0.0
```

Asegúrate de que Ollama esté activo:

```bash
ollama list
ollama serve
```

Si Ollama ya está ejecutándose como servicio, no necesitas lanzar `ollama serve`
una segunda vez.

### Endpoint OpenAI-compatible

También se admite, pero el formato de respuesta depende de lo que implemente el
servidor. Para la salida estructurada más estricta se recomienda el endpoint
nativo de Ollama.

```env
LLM_API_URL=http://127.0.0.1:11434/v1/chat/completions
LLM_MODEL=qwen3.5:4b
LLM_API_KEY=EMPTY
```

### vLLM

```env
LLM_API_URL=http://127.0.0.1:9001/v1/chat/completions
LLM_MODEL=nombre-del-modelo-servido
LLM_API_KEY=EMPTY
```

## Ejecutar

Desde `regex_studio/`:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

- Interfaz: http://localhost:8000
- Swagger: http://localhost:8000/docs
- Salud: http://localhost:8000/api/health

## Ajustes de experimentación

Variables principales en `.env`:

| Variable | Predeterminado | Uso |
|---|---:|---|
| `MAX_CYCLES` | 3 | Ciclos de generación |
| `CANDIDATES_PER_CYCLE` | 3 | Candidatos por ciclo |
| `VARIATIONS` | 12 | Reformulaciones adicionales por candidato |
| `MIN_RECALL` | 85 | Recall mínimo requerido |
| `MIN_SPECIFICITY` | 90 | Especificidad mínima requerida |
| `REGEX_TIMEOUT_SECONDS` | 0.05 | Tiempo máximo por prueba |
| `LLM_TIMEOUT_SECONDS` | 120 | Timeout del modelo |

## Pruebas automáticas

```bash
python -m pytest -v
```

## Evaluación semántica: importante

Los positivos y negativos propuestos por el modelo son un conjunto inicial de
pruebas, no una verdad de referencia. Un regex aprobado significa que pasó ese
conjunto; no demuestra por sí solo que entienda todos los casos reales. Para
uso productivo conviene mantener un dataset propio, revisado y etiquetado, con
frases reales positivas, negativas y casos ambiguos.

El motor no amplía automáticamente el patrón para hacerlo coincidir con todo:
prioriza precisión y feedback de fallos. Un patrón demasiado permisivo puede
aprobar positivos pero también capturar frases que no corresponden.

## Persistencia y límites operativos

La base SQLite se crea en `data/regex_studio.db`. Los eventos, candidatos y
resultados de pruebas se conservan. El streaming y las tareas viven en memoria
para una sola instancia FastAPI; para varios workers o recuperación tras un
reinicio, se recomienda Redis/broker. No expongas el servicio directamente a
Internet sin autenticación, rate limits y controles de acceso.
