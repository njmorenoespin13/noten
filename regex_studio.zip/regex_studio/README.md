# Regex Intelligence Studio

Aplicación local para generar, probar, comparar y conservar expresiones regulares
estructuradas usando FastAPI, WebSockets, SQLite y un LLM compatible con la API
de chat de OpenAI (por ejemplo Ollama o vLLM).

## Requisitos

- Python 3.10+
- Ollama o vLLM accesible desde el servidor
- Modelo disponible en el endpoint configurado

## Instalación

### Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

### Windows PowerShell

```powershell
py -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

La configuración se realiza mediante variables de entorno. Para cargarlas desde
un archivo `.env`, puedes instalar `python-dotenv` y ejecutar `load_dotenv()`
al inicio de `config.py`, o exportar las variables en tu terminal.

## Configurar Ollama

Ajusta `LLM_API_URL` y `LLM_MODEL`:

```bash
export LLM_API_URL=http://127.0.0.1:11434/v1/chat/completions
export LLM_MODEL=qwen3:14b
export LLM_API_KEY=EMPTY
```

## Configurar vLLM

```bash
export LLM_API_URL=http://127.0.0.1:9001/v1/chat/completions
export LLM_MODEL=nombre-del-modelo-servido
export LLM_API_KEY=EMPTY
```

## Ejecutar

Desde la raíz del proyecto:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

Abrir:

- Interfaz: http://localhost:8000
- Swagger: http://localhost:8000/docs
- Salud: http://localhost:8000/api/health

## Pruebas

```bash
pytest -v
```

## Persistencia

La base SQLite se crea automáticamente en `data/regex_studio.db`.
Los eventos, candidatos y resultados de pruebas quedan almacenados.

## Funcionamiento

Cada experimento ejecuta varios ciclos y varios candidatos por ciclo. Todos los
candidatos se guardan. Al final se selecciona el candidato aprobado con mejor
puntuación; un candidato rechazado nunca desplaza a uno aprobado.

La evaluación usa recall de ejemplos positivos y especificidad de ejemplos
negativos. Los ejemplos los propone el LLM, por lo que una aprobación no
demuestra por sí sola calidad semántica real. Para producción, incorpora un
dataset etiquetado y revisado independientemente.

## Notas operativas

- El paquete `regex` permite aplicar timeout al evaluar patrones.
- No expongas el servicio directamente a Internet sin autenticación, límites
  de uso y controles de acceso.
- Este proyecto usa tareas y eventos en memoria para una sola instancia
  de FastAPI. Para múltiples workers o recuperación de streaming tras reinicio,
  incorpora Redis o un broker de eventos.
- Los datos SQLite persisten aunque se reinicie el servidor.
