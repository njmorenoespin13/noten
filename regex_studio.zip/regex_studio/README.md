# Regex Intelligence Studio

Aplicación local para proponer regex lingüísticos flexibles, probarlos en vivo,
comparar versiones y conservar el historial. Incluye FastAPI, WebSockets,
SQLite y conexión con Ollama o un endpoint OpenAI-compatible.

## Modos de generación

En la interfaz puedes seleccionar uno de estos modos por experimento:

### Flexible semántico

El modelo genera regex por componentes semánticos y alternativas de sinónimos.
Primero crea un conjunto compartido de paráfrasis (no solo cambios de tildes) y
cada candidato se valida contra los mismos positivos y negativos. El texto se
prueba sin normalizar, para aproximarse al texto original que recibirá PostgreSQL.

### Estricto por componentes

No llama al LLM para construir el patrón. Extrae las palabras relevantes de la
frase, las conserva en el mismo orden y genera un regex determinista. Exige esos
componentes clave, pero tolera mayúsculas, tildes mediante clases de caracteres, signos de
puntuación y texto intermedio entre componentes. No busca sinónimos
ni reordena las palabras clave.

Ejemplo conceptual: para `permiso para la línea de internet`, el modo estricto
conserva `permiso`, `linea`, `internet` y admite puntuación o palabras puente
entre ellos. La validación se realiza sobre el texto original, sin quitar tildes ni puntuación.

Este modo está pensado para detectar menciones de una frase concreta. No realiza
comprensión de negaciones: si una frase contiene todos los componentes clave en
el orden esperado, puede coincidir aunque esté dentro de una oración negativa.

## Cambios de esta versión

- Selector de modo por experimento: flexible semántico o estricto por componentes.
- El modo estricto construye regex determinista sin depender del JSON del modelo.
- El modo flexible genera paráfrasis semánticas una vez por experimento y las muestra en vivo.
- Cada candidato recibe como contexto los positivos fallidos y falsos positivos del intento anterior.
  Los positivos no detectados se agregan a los requisitos del siguiente intento.
- El modo flexible valida sobre el texto original y solicita patrones con sinónimos, raíces,
  clases de tildes y tramos flexibles (`.*?`, `.{0,100}`, `(?:...)`).
- Las paráfrasis usan una temperatura independiente (`VARIATION_TEMPERATURE`) para ganar diversidad,
  mientras la generación del regex mantiene una temperatura baja para respetar JSON.
- Se agrega timeout a las llamadas LLM y se muestran eventos de generación, validación y ajuste.
- El patrón se comprueba contra construcciones comunes no compatibles con PostgreSQL ARE.
- Para Ollama nativo se envía un JSON Schema en `format`, en lugar de confiar
  únicamente en que el modelo recuerde producir JSON válido.
- Temperatura 0 por defecto y modelo inicial `qwen3.5:4b`.
- Las pruebas se emiten individualmente por WebSocket y aparecen en la interfaz
  conforme se ejecutan, con PASS/FAIL, tipo, frase y contador.
- Se reproduce el historial de eventos al conectar el WebSocket; así no se
  pierden las interacciones si la tarea empieza antes de abrir el socket.
- Se guardan candidatos, métricas, pruebas y eventos en SQLite.

## Requisitos e instalación

Python 3.10+, Ollama instalado y el modelo descargado.

### Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
ollama pull qwen3.5:4b
```

### Windows PowerShell

```powershell
py -m venv venv
venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
ollama pull qwen3.5:4b
```

## Configuración recomendada para Ollama

El endpoint nativo `/api/chat` permite usar JSON Schema estructurado:

```env
LLM_API_URL=http://127.0.0.1:11434/api/chat
LLM_MODEL=qwen3.5:4b
LLM_API_KEY=
LLM_TEMPERATURE=0.0
```

Asegúrate de que Ollama esté activo:

```bash
ollama list
ollama serve
```

Si Ollama ya está ejecutándose como servicio, no necesitas lanzar `ollama serve`
una segunda vez.

### Endpoint OpenAI-compatible

También se admite, pero el formato de respuesta depende de lo que implemente el
servidor. Para la salida estructurada más estricta se recomienda el endpoint
nativo de Ollama.

```env
LLM_API_URL=http://127.0.0.1:11434/v1/chat/completions
LLM_MODEL=qwen3.5:4b
LLM_API_KEY=EMPTY
```

### vLLM

```env
LLM_API_URL=http://127.0.0.1:9001/v1/chat/completions
LLM_MODEL=nombre-del-modelo-servido
LLM_API_KEY=EMPTY
```

## Ejecutar

Desde `regex_studio/`:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

- Interfaz: http://localhost:8000
- Swagger: http://localhost:8000/docs
- Salud: http://localhost:8000/api/health

## Ajustes de experimentación

Variables principales en `.env`:

| Variable | Predeterminado | Uso |
|---|---:|---|
| `MAX_CYCLES` | 3 | Ciclos de generación |
| `CANDIDATES_PER_CYCLE` | 3 | Candidatos por ciclo |
| `VARIATIONS` | 12 | Paráfrasis semánticas generadas una vez por experimento |
| `MIN_RECALL` | 85 | Recall mínimo requerido |
| `MIN_SPECIFICITY` | 90 | Especificidad mínima requerida |
| `REGEX_TIMEOUT_SECONDS` | 0.05 | Tiempo máximo por prueba |
| `LLM_TIMEOUT_SECONDS` | 45 | Timeout del modelo |
| `VARIATION_TEMPERATURE` | 0.25 | Diversidad de paráfrasis semánticas |

## Pruebas automáticas

```bash
python -m pytest -v
```

## Evaluación semántica: importante

Los positivos y negativos propuestos por el modelo son un conjunto inicial de
pruebas, no una verdad de referencia. Un regex aprobado significa que pasó ese
conjunto; no demuestra por sí solo que entienda todos los casos reales. Para
uso productivo conviene mantener un dataset propio, revisado y etiquetado, con
frases reales positivas, negativas y casos ambiguos.

El motor usa los errores como retroalimentación para solicitar un nuevo candidato.
No reescribe el regex mediante sustituciones ciegas: el LLM propone una versión
ajustada y el motor la vuelve a medir con el conjunto acumulado de positivos y negativos.
Un patrón demasiado permisivo puede cubrir más paráfrasis y también capturar frases
que no corresponden.

## Persistencia y límites operativos

La base SQLite se crea en `data/regex_studio.db`. Los eventos, candidatos y
resultados de pruebas se conservan. El streaming y las tareas viven en memoria
para una sola instancia FastAPI; para varios workers o recuperación tras un
reinicio, se recomienda Redis/broker. No expongas el servicio directamente a
Internet sin autenticación, rate limits y controles de acceso.


## Uso del regex directamente en PostgreSQL

Los patrones se generan y validan contra el texto original, no contra una copia sin tildes.
El motor intenta usar sintaxis compatible con PostgreSQL ARE. Las variantes de vocales
acentuadas se expresan con clases como `[ií]`, por lo que no necesitas ejecutar `unaccent()`
para los patrones generados por el modo estricto.

Usa el operador `~*` para coincidencia sin distinguir mayúsculas/minúsculas y parámetros
para enviar el patrón (no lo concatentes dentro del SQL):

```sql
SELECT *
FROM comunicaciones
WHERE texto ~* %s;
```

Ejemplo con psycopg:

```python
cur.execute(
    "SELECT id, texto FROM comunicaciones WHERE texto ~* %s",
    (regex_generado,)
)
```

**Importante:** PostgreSQL recibe el patrón como parámetro. No agregues comillas dobles
extra alrededor del patrón ni lo escapes manualmente. Si el patrón proviene del modo
semántico, revisa que use clases de acentos cuando necesites reconocer ambas escrituras.
La aplicación prueba el patrón en Python contra el texto original; la confirmación definitiva
de compatibilidad debe hacerse también en tu versión de PostgreSQL.
