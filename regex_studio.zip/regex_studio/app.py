import asyncio
import logging
import uuid
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import database as db
from engine import RegexEngine
from config import settings


Path("logs").mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("logs/regex_studio.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("RegexStudio")


@asynccontextmanager
async def lifespan(app):
    db.initialize()
    yield


app = FastAPI(
    title="Regex Intelligence Studio",
    version="1.0.0",
    lifespan=lifespan
)
app.mount("/static", StaticFiles(directory="static"), name="static")

engine = RegexEngine()
subscribers = {}
tasks = {}


class ExperimentRequest(BaseModel):
    phrase: str = Field(min_length=3, max_length=settings.max_phrase_length)


async def broadcast(job_id, event):
    event = dict(event)
    event["event_id"] = db.save_event(
        job_id,
        event.get("event", "unknown"),
        event.get("message", event.get("event", "")),
        event
    )
    for queue in list(subscribers.get(job_id, [])):
        await queue.put(event)
    return event


@app.get("/")
async def home():
    return FileResponse("static/index.html")


@app.post("/api/experiments")
async def create_experiment(request: ExperimentRequest):
    phrase = request.phrase.strip()
    if len(phrase) < 3:
        raise HTTPException(400, "La frase debe tener al menos 3 caracteres.")

    job_id = str(uuid.uuid4())
    db.create_job(job_id, phrase)

    async def publish(event):
        if event.get("event") == "candidate":
            candidate_id = db.save_candidate(job_id, event["version"], event["result"])
            event["result"]["db_id"] = candidate_id
        await broadcast(job_id, event)

    async def execute():
        try:
            result = await engine.run(job_id, phrase, publish)
            if result and result.get("valid"):
                db.finish_job(
                    job_id, result.get("regex"),
                    result.get("score", 0), "completed"
                )
            else:
                db.finish_job(
                    job_id, None,
                    result.get("score", 0) if result else 0,
                    "failed"
                )
        except Exception as exc:
            logger.exception("Error ejecutando experimento %s", job_id)
            db.finish_job(job_id, status="failed")
            await broadcast(job_id, {
                "event": "error", "message": str(exc)
            })
        finally:
            await broadcast(job_id, {"event": "task_finished"})
            tasks.pop(job_id, None)

    tasks[job_id] = asyncio.create_task(execute())
    return {"job_id": job_id, "status": "running"}


@app.websocket("/ws/{job_id}")
async def websocket_endpoint(websocket: WebSocket, job_id: str):
    if db.get_job(job_id) is None:
        await websocket.close(code=1008)
        return
    await websocket.accept()
    queue = asyncio.Queue()
    # Suscribirse antes de leer el snapshot evita perder eventos que ocurran
    # entre la consulta del historial y el alta del WebSocket.
    subscribers.setdefault(job_id, []).append(queue)
    snapshot = db.get_job(job_id)
    last_id = 0
    try:
        for saved in snapshot.get("events", []):
            details = saved.get("details", {})
            details["event_id"] = saved["id"]
            await websocket.send_json(details)
            last_id = max(last_id, saved["id"])
        if job_id not in tasks:
            if not snapshot.get("events") or snapshot["events"][-1].get("event_type") != "task_finished":
                await websocket.send_json({"event": "task_finished"})
            return
        while True:
            event = await queue.get()
            if event.get("event_id", 0) <= last_id:
                continue
            last_id = event.get("event_id", last_id)
            await websocket.send_json(event)
            if event.get("event") == "task_finished":
                break
    except WebSocketDisconnect:
        logger.info("WebSocket desconectado: %s", job_id)
    finally:
        current = subscribers.get(job_id, [])
        if queue in current:
            current.remove(queue)
        if not current:
            subscribers.pop(job_id, None)


@app.get("/api/history")
async def history():
    return db.get_history()


@app.get("/api/experiments/{job_id}")
async def experiment_detail(job_id: str):
    result = db.get_job(job_id)
    if result is None:
        raise HTTPException(404, "Experimento no encontrado.")
    return result


@app.get("/api/candidates/{candidate_id}/tests")
async def candidate_tests(candidate_id: int):
    return db.get_candidate_tests(candidate_id)


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "model": settings.model,
        "active_experiments": len(tasks)
    }
