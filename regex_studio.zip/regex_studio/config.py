import os
from dataclasses import dataclass


@dataclass
class Settings:
    api_url: str = os.getenv(
        "LLM_API_URL",
        "http://127.0.0.1:11434/v1/chat/completions"
    )
    model: str = os.getenv("LLM_MODEL", "qwen3:14b")
    api_key: str = os.getenv("LLM_API_KEY", "EMPTY")
    max_cycles: int = int(os.getenv("MAX_CYCLES", "3"))
    candidates_per_cycle: int = int(os.getenv("CANDIDATES_PER_CYCLE", "3"))
    variations: int = int(os.getenv("VARIATIONS", "20"))
    min_recall: float = float(os.getenv("MIN_RECALL", "90"))
    min_specificity: float = float(os.getenv("MIN_SPECIFICITY", "95"))
    regex_timeout_seconds: float = float(os.getenv("REGEX_TIMEOUT_SECONDS", "0.05"))
    llm_timeout_seconds: int = 120
    max_phrase_length: int = 1000
    max_regex_length: int = 2000


settings = Settings()
