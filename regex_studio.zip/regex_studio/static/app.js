const $ = id => document.getElementById(id);
let currentJob = null, candidateCount = 0, approvedCount = 0, rejectedCount = 0;

function log(message, type="") {
  const node = document.createElement("div");
  node.className = "log " + type;
  node.textContent = `${new Date().toLocaleTimeString()} | ${message}`;
  $("logs").appendChild(node);
  $("logs").scrollTop = $("logs").scrollHeight;
}
function resetView() {
  candidateCount = approvedCount = rejectedCount = 0;
  $("count").textContent = "0"; $("approved").textContent = "0"; $("rejected").textContent = "0";
  $("candidateRows").replaceChildren(); $("logs").replaceChildren(); $("liveTests").replaceChildren();
  $("finalRegex").textContent = "Experimentando..."; $("explanation").textContent = "—";
  $("structure").textContent = "—"; $("progress").style.width = "0%";
  $("testPhase").textContent = "Esperando pruebas..."; $("testCounter").textContent = "0 / 0";
}
async function startExperiment() {
  const phrase = $("phrase").value.trim();
  if (phrase.length < 3) return alert("Escribe una frase de al menos 3 caracteres.");
  $("start").disabled = true; resetView();
  try {
    const response = await fetch("/api/experiments", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({phrase})});
    const data = await response.json(); if (!response.ok) throw new Error(data.detail || "No se pudo iniciar");
    currentJob = data.job_id; log(`Experimento iniciado: ${currentJob}`, "success");
    connectSocket(currentJob); loadHistory();
  } catch (error) { log(error.message, "error"); $("start").disabled = false; }
}
function connectSocket(jobId) {
  const scheme = location.protocol === "https:" ? "wss" : "ws";
  const socket = new WebSocket(`${scheme}://${location.host}/ws/${jobId}`);
  socket.onopen = () => $("connection").textContent = "CONECTADO";
  socket.onmessage = event => handleEvent(JSON.parse(event.data));
  socket.onerror = () => log("Error en WebSocket", "error");
  socket.onclose = () => $("connection").textContent = "API";
}
function handleEvent(data) {
  if (data.event === "cycle" || data.event === "generating" || data.event === "generating_variations") {
    $("phase").textContent = data.message; log(data.message);
  } else if (data.event === "candidate_generated") {
    $("finalRegex").textContent = data.regex || "Regex no disponible";
    $("explanation").textContent = data.explanation || "Validando candidato...";
    log(`V${data.version}: ${data.regex}`, "success");
  } else if (data.event === "test_batch_start") {
    $("testPhase").textContent = `V${data.version} · ${data.phase}`;
    $("testCounter").textContent = `0 / ${data.total}`;
    const marker = document.createElement("div"); marker.className = "log"; marker.textContent = `──── ${data.phase} · V${data.version} ────`; $("liveTests").appendChild(marker);
    log(data.message);
  } else if (data.event === "test") {
    appendLiveTest(data);
  } else if (data.event === "test_batch_done") {
    const r = data.result || {};
    $("testPhase").textContent = `V${data.version} · ${data.phase} · score ${r.score ?? 0}%`;
    log(`V${data.version}: recall ${r.recall ?? 0}% · especificidad ${r.specificity ?? 0}%`);
  } else if (data.event === "candidate") {
    addCandidate(data.version, data.result);
  } else if (data.event === "candidate_error") {
    log(data.message, "error");
  } else if (data.event === "final") {
    showFinal(data.result); $("phase").textContent = "Mejor candidato aprobado";
    $("progress").style.width = "100%"; log("Regex final seleccionado", "success");
  } else if (data.event === "finished") {
    $("phase").textContent = data.message; if (data.result) showFinal(data.result); log(data.message, "error");
  } else if (data.event === "error") log(data.message, "error");
  else if (data.event === "task_finished") { $("start").disabled = false; $("progress").style.width = "100%"; loadHistory(); }
}
function appendLiveTest(data) {
  const t = data.test; const div = document.createElement("div");
  div.className = `test ${t.passed ? "ok" : "fail"}`;
  const status = t.passed ? "PASS" : "FAIL";
  div.append(document.createTextNode(`${data.index}/${data.total} · ${status} · ${t.type} · ${t.actual ? "coincide" : "no coincide"}`));
  const detail = document.createElement("span"); detail.className = "detail"; detail.textContent = t.phrase;
  div.appendChild(detail); $("liveTests").appendChild(div);
  $("testCounter").textContent = `${data.index} / ${data.total}`;
  $("liveTests").scrollTop = $("liveTests").scrollHeight;
}
function addCandidate(version, result) {
  candidateCount++; if (result.valid) approvedCount++; else rejectedCount++;
  $("count").textContent = candidateCount; $("approved").textContent = approvedCount; $("rejected").textContent = rejectedCount;
  const row = document.createElement("tr"); row.dataset.id = result.db_id || "";
  [`V${version}`, result.status || (result.valid ? "approved" : "rejected"), `${result.score ?? 0}%`, `${result.recall ?? 0}%`, `${result.specificity ?? 0}%`, `${result.duration ?? 0}s`].forEach((value, i) => {
    const cell = document.createElement("td"); cell.textContent = value; if (i === 1) cell.className = result.valid ? "green" : "red"; row.appendChild(cell);
  });
  row.onclick = () => showTests(result); $("candidateRows").appendChild(row);
  $("progress").style.width = `${Math.min(95, candidateCount * 10)}%`;
  log(`V${version}: ${result.status} | score ${result.score ?? 0}%`, result.valid ? "success" : "error");
}
function showTests(result) {
  $("tests").replaceChildren(); const summary = document.createElement("p");
  summary.textContent = `Score: ${result.score ?? 0}% · ${result.tests?.length ?? 0} pruebas`; $("tests").appendChild(summary);
  (result.tests || []).forEach(test => { const div = document.createElement("div"); div.className = `test ${test.passed ? "green" : "red"}`; div.textContent = `${test.passed ? "OK" : "FAIL"} | ${test.type} | ${test.phrase}`; $("tests").appendChild(div); });
}
function showFinal(result) {
  if (!result) return; $("finalRegex").textContent = result.regex || "No hay regex final.";
  $("explanation").textContent = result.explanation || "—"; $("structure").textContent = JSON.stringify(result.structure || {}, null, 2);
}
async function loadHistory() {
  const response = await fetch("/api/history"); const rows = await response.json(); $("history").replaceChildren();
  rows.forEach(item => { const div = document.createElement("div"); div.className = "history-item"; const title = document.createElement("strong"); title.textContent = item.phrase; const meta = document.createElement("small"); meta.textContent = `\n${item.status} · ${item.total_candidates} candidatos · ${item.created_at}`; div.append(title, meta); div.onclick = () => loadExperiment(item.id); $("history").appendChild(div); });
}
async function loadExperiment(id) {
  const response = await fetch(`/api/experiments/${id}`); if (!response.ok) return; const data = await response.json();
  currentJob = id; $("phrase").value = data.phrase; $("candidateRows").replaceChildren(); $("logs").replaceChildren();
  candidateCount = approvedCount = rejectedCount = 0;
  data.candidates.forEach(candidate => {
    candidateCount++; const approved = candidate.status === "approved"; if (approved) approvedCount++; else rejectedCount++;
    const row = document.createElement("tr"); row.dataset.id = candidate.id;
    [`V${candidate.version}`, candidate.status, `${candidate.score}%`, `${candidate.recall_score}%`, `${candidate.specificity_score}%`, `${candidate.duration}s`].forEach((value, i) => { const cell = document.createElement("td"); cell.textContent = value; if (i === 1) cell.className = approved ? "green" : "red"; row.appendChild(cell); });
    row.onclick = async () => { const r = await fetch(`/api/candidates/${candidate.id}/tests`); const tests = await r.json(); showTests({score:candidate.score, tests}); }; $("candidateRows").appendChild(row);
  });
  $("count").textContent = candidateCount; $("approved").textContent = approvedCount; $("rejected").textContent = rejectedCount;
  $("finalRegex").textContent = data.final_regex || "No se aprobó ningún regex."; $("phase").textContent = `Histórico: ${data.status}`;
  data.events.forEach(event => log(event.message)); const winner = data.candidates.find(c => c.regex === data.final_regex);
  if (winner) { $("explanation").textContent = winner.explanation || "—"; $("structure").textContent = JSON.stringify(winner.structure || {}, null, 2); }
}
$("start").addEventListener("click", startExperiment);
$("copy").addEventListener("click", async () => { await navigator.clipboard.writeText($("finalRegex").textContent); log("Regex copiado al portapapeles", "success"); });
loadHistory();
fetch("/api/health").then(r => r.json()).then(() => { $("connection").textContent = "API ONLINE"; }).catch(() => { $("connection").textContent = "API OFFLINE"; });
