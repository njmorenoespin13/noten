import json
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path("data/regex_studio.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect():
    db = sqlite3.connect(DB_PATH, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    return db


def initialize():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            phrase TEXT NOT NULL,
            status TEXT NOT NULL,
            final_regex TEXT,
            final_score REAL DEFAULT 0,
            total_candidates INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            finished_at TEXT
        );

        CREATE TABLE IF NOT EXISTS candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id TEXT NOT NULL,
            version INTEGER NOT NULL,
            regex TEXT,
            explanation TEXT,
            structure_json TEXT,
            status TEXT NOT NULL,
            score REAL DEFAULT 0,
            recall_score REAL DEFAULT 0,
            specificity_score REAL DEFAULT 0,
            positive_total INTEGER DEFAULT 0,
            positive_passed INTEGER DEFAULT 0,
            negative_total INTEGER DEFAULT 0,
            negative_passed INTEGER DEFAULT 0,
            duration REAL DEFAULT 0,
            error TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        );

        CREATE TABLE IF NOT EXISTS tests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            candidate_id INTEGER NOT NULL,
            phrase TEXT NOT NULL,
            expected INTEGER NOT NULL,
            actual INTEGER NOT NULL,
            passed INTEGER NOT NULL,
            test_type TEXT NOT NULL,
            FOREIGN KEY(candidate_id) REFERENCES candidates(id)
        );

        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            message TEXT NOT NULL,
            details_json TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        );

        CREATE INDEX IF NOT EXISTS idx_candidates_job
        ON candidates(job_id, version);

        CREATE INDEX IF NOT EXISTS idx_events_job
        ON events(job_id, id);
        """)


def create_job(job_id, phrase):
    with connect() as db:
        db.execute(
            "INSERT INTO jobs(id, phrase, status, created_at) VALUES(?, ?, 'running', ?)",
            (job_id, phrase, now())
        )


def save_candidate(job_id, version, result):
    with connect() as db:
        cur = db.execute("""
            INSERT INTO candidates (
                job_id, version, regex, explanation, structure_json,
                status, score, recall_score, specificity_score,
                positive_total, positive_passed, negative_total,
                negative_passed, duration, error, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            job_id, version, result.get("regex"),
            result.get("explanation", ""),
            json.dumps(result.get("structure", {}), ensure_ascii=False),
            result.get("status", "rejected"),
            result.get("score", 0), result.get("recall", 0),
            result.get("specificity", 0),
            result.get("positive_total", 0),
            result.get("positive_passed", 0),
            result.get("negative_total", 0),
            result.get("negative_passed", 0),
            result.get("duration", 0), result.get("error"), now()
        ))
        candidate_id = cur.lastrowid
        for test in result.get("tests", []):
            db.execute("""
                INSERT INTO tests(candidate_id, phrase, expected, actual, passed, test_type)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                candidate_id, test["phrase"], int(test["expected"]),
                int(test["actual"]), int(test["passed"]), test["type"]
            ))
        db.execute(
            "UPDATE jobs SET total_candidates = total_candidates + 1 WHERE id = ?",
            (job_id,)
        )
        return candidate_id


def save_event(job_id, event_type, message, details=None):
    with connect() as db:
        cur = db.execute("""
            INSERT INTO events(job_id, event_type, message, details_json, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            job_id, event_type, message,
            json.dumps(details, ensure_ascii=False) if details is not None else None,
            now()
        ))
        return cur.lastrowid


def finish_job(job_id, regex=None, score=0, status="completed"):
    with connect() as db:
        db.execute("""
            UPDATE jobs SET status=?, final_regex=?, final_score=?, finished_at=?
            WHERE id=?
        """, (status, regex, score, now(), job_id))


def get_history():
    with connect() as db:
        return [dict(r) for r in db.execute(
            "SELECT * FROM jobs ORDER BY created_at DESC"
        ).fetchall()]


def get_job(job_id):
    with connect() as db:
        job = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not job:
            return None
        result = dict(job)
        result["candidates"] = [
            dict(r) for r in db.execute(
                "SELECT * FROM candidates WHERE job_id=? ORDER BY version",
                (job_id,)
            ).fetchall()
        ]
        for candidate in result["candidates"]:
            try:
                candidate["structure"] = json.loads(candidate.pop("structure_json") or "{}")
            except json.JSONDecodeError:
                candidate["structure"] = {}
        result["events"] = [
            dict(r) for r in db.execute(
                "SELECT * FROM events WHERE job_id=? ORDER BY id",
                (job_id,)
            ).fetchall()
        ]
        for event in result["events"]:
            try:
                event["details"] = json.loads(event.pop("details_json") or "{}")
            except json.JSONDecodeError:
                event["details"] = {}
        return result


def get_candidate_tests(candidate_id):
    with connect() as db:
        return [dict(r) for r in db.execute(
            "SELECT * FROM tests WHERE candidate_id=? ORDER BY id",
            (candidate_id,)
        ).fetchall()]
